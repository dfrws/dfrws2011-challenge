#pragma once

#include "targetver.h"

#include <stdio.h>
#include <tchar.h>
#define _ATL_CSTRING_EXPLICIT_CONSTRUCTORS      // 

#ifndef VC_EXTRALEAN
#define VC_EXTRALEAN            // 
#endif

#include <afx.h>
#include <afxwin.h>         // 
#include <afxext.h>         // 
#ifndef _AFX_NO_OLE_SUPPORT
#include <afxdtctl.h>           // 
#endif
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>                     // 
#endif // _AFX_NO_AFXCMN_SUPPORT

#include <iostream>
 #include <comdef.h>
 #include <afxpriv.h> 
#include <comdef.h>
#include <CRTDBG.H>
#include <atlconv.h>
#include <afxtempl.h>
//
