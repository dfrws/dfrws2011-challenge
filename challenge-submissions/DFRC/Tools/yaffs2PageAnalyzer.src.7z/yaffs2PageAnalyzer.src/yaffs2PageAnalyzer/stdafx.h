#pragma once

#include <stdio.h>
#include <tchar.h>
#define _ATL_CSTRING_EXPLICIT_CONSTRUCTORS     

#ifndef VC_EXTRALEAN
#define VC_EXTRALEAN         
#endif

#include <afx.h>
#include <afxwin.h>        
#include <afxext.h>        
#ifndef _AFX_NO_OLE_SUPPORT
#include <afxdtctl.h>      
#endif
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>        
#endif 

#include <iostream>

